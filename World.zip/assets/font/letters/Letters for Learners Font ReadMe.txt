Letters for Learners (c) Brittney Murphy 2017
Letters for Learners Dots (c) Brittney Murphy 2017
Letters for Learners Lined (c) Brittney Murphy 2017
Letters for Learners Lined Dots (c) Brittney Murphy 2017
www.brittneymurphydesign.com
info@brittneymurphydesign.com

By installing or using these fonts you agree to the following:

You may NOT redistribute this font without written permission.

FREE FOR PERSONAL USE, OR FOR TEACHERS FOR USE IN THEIR CLASSROOMS ONLY. 
For creating teaching products for sale or distribution, or any other commercial use, please purchase a license here: 
https://brittneymurphydesign.com/downloads/letters-for-learners-font-family/ 

For more information about licensing, visit:
http://brittneymurphydesign.com/fonts/font-commercial-licenses/




